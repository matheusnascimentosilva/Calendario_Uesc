package codes;

import java.util.GregorianCalendar;

public class App {

	@SuppressWarnings("unused")
	private static meu_Tema define;
	@SuppressWarnings("unused")
	private static MeuCalendario e;

	public static void main(String[] args) {
		define = new meu_Tema();
		meu_Tema.AplicaNimbus();
		GregorianCalendar cal=new GregorianCalendar();
		e = new MeuCalendario(cal);
		
		//Meses m = new Meses();
		//int x = 10;
		//System.out.println(m.getMes(x));
		}

	}

