/*
 * TEMA NIMBUS PARA ESTILIZA��O DA INTERFACE
 * EDITADO POR: MATHEUS NASCIMENTO SILVA
 * CONFIGURADO PARA FAZER OBJETOS DO TIPO MEU TEMA
 * FICA LIVRE A EDI��O DA CLASSE PARA MELHORAR DESEMPENHO
 * CURSO: CI�NCIA DA COMPUTA��O - UESC
 * */
package codes;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.UIManager.LookAndFeelInfo;

public class meu_Tema {

		meu_Tema(){
			
		}

		public static void AplicaNimbus() {
			try {
				for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
					if ("Nimbus".equals(info.getName())) {
						UIManager.setLookAndFeel(info.getClassName());
						break;
					}
				}
			} catch (UnsupportedLookAndFeelException e) {

				System.out.println("Erro: " + e.getMessage());
				e.printStackTrace();

			} catch (ClassNotFoundException e) {

				System.out.println("Erro: " + e.getMessage());
				e.printStackTrace();

			} catch (InstantiationException e) {

				System.out.println("Erro: " + e.getMessage());
				e.printStackTrace();

			} catch (IllegalAccessException e) {

				System.out.println("Erro: " + e.getMessage());
				e.printStackTrace();
			}
		}
	}

