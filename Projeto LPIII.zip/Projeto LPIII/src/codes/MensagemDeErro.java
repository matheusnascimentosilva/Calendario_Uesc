package codes;

public class MensagemDeErro {
	@SuppressWarnings("unused")
	private boolean verifcaCampo(String valor) {
		return valor!=null;
	}

}
